<?php 
/*
Plugin Name: Bizzle Custom AJAX Login/Register
Description: Controls a Seamless AJAX Powered Login and/or Register Modal
Version:     1.0
Author:      Rob Ruiz
*/

/*Adds code for the custom ajax login/register/lost password modal to the wp footer hook*/
if ( ! function_exists( 'hsi_user_modal' ) ) {
	function hsi_user_modal() {
			if ( !is_user_logged_in() ) { ?>
				<div class="modal fade" id="login-reg-modal" tabindex="-1" role="dialog" aria-hidden="true" data-remodal-id="login-reg-modal" style="display:none;">
				    <div class="modal-dialog hsi-login-modal">
				    	<div class="modal-content">
				    		<div class="modal-header">
			                    <div class="close"><a class="close-modal" data-dismiss="modal" href="#"><span class="icon_close"></span></a></div>
								<h2 class="modal-title">Who Are You?</h2>
			                </div>
                             <form action="<?php echo admin_url('admin-ajax.php'); ?>" method="POST" id="hsi-login-register">
							<section class="modal-side login">
                            <div id="back-register" style="display:none;"><button class="btn button">Register Instead <i class="fa fa-arrow-right" aria-hidden="true"></i></button></div>
                            <h3>Already Have An Account?</h3>
								<div id="email" class="login-field">
                                    <label for="login-email">Email: </label>
                                    <input type="email" placeceholder="email" id="login-email">
								</div>
                                <div id="password" class="login-field">
                                    <label for="login-password">Password: </label>
                                    <input type="password" id="login-password">
								</div>
                                <div id="remember" class="login-field">
                                    <label for="remember-password">Remember Password? </label>
                                    <input type="checkbox" id="remember-password">
								</div>
							<div class="account-links"><a href="/wp-login.php?action=lostpassword">Forgot Your Password?</a></div>
					    </section>
                        <section class="modal-side register">
                       		<div id="back-login" style="display:none;"><button class="btn button"><i class="fa fa-arrow-left" aria-hidden="true"></i> Login Instead</button></div>
							<h3>No Account? No Problem!</h3>
                                <div id="first-name" class="register-field">
                                    <label for="first-name">First Name: </label>
                                    <input type="text" id="first-name">
								</div>
                                <div id="last-name" class="register-field">
                                    <label for="last-name">Last Name: </label>
                                    <input type="text" id="last-name">
								</div>
                                <div id="email" class="register-field">
                                    <label for="register-email">Email: </label>
                                    <input type="email" id="register-email">
								</div>
                                <div id="set-password" class="register-field">
                                    <label for="register-password">Password: </label>
                                    <input type="password" id="register-password">
								</div>
                                 <div class="g-recaptcha" data-sitekey="6LdmOwsTAAAAALiINhOnHmRI40R1dIM2blSDgJJy"></div>
				    	</section>
                        <div id="bottom-button">
                       	 <button id="hsi-login-modal-continue" class="hsi-login-register btn" type="submit">Continue</button>
                        </div>
                       
                        </form>
				</div>

				<?php if ( get_option( 'users_can_register' ) ) { ?>
					<div class="modal fade" id="myModalRegister" tabindex="-1" role="dialog" aria-hidden="true">
					    <div class="modal-dialog">
					    	<div class="modal-content">
					    		<div class="modal-header">
			                        <div class="close"><a class="close-modal" data-dismiss="modal" href="#"><span class="icon_close"></span></a></div>
			    					<h2 class="modal-title"><?php _e( 'Create Account', 'Aktina' ); ?></h2>
			                    </div>
								<div class="modal-body">
									<?php echo do_shortcode('[formidable id=8]');?>
								</div>
								<div class="modal-footer default">
									<?php _e( "Already have an account?", 'Aktina' ); ?> 
									<a href="#" class="login-modal modal-link" data-toggle="modal" data-target="#myModalLogin"><?php _e( "Login!", 'Aktina' ); ?></a>
								</div>
						    </div>
					    </div>
					</div>
				<?php } ?>

				<!--<div class="modal fade" id="myModalLost" tabindex="-1" role="dialog" aria-hidden="true">
				    <div class="modal-dialog">
				    	<div class="modal-content">
				    		<div class="modal-header">
			                    <div class="close"><a class="close-modal" data-dismiss="modal" href="#"><span class="icon_close"></span></a></div>
								<h2 class="modal-title"><?php /*_e( 'Forget your password?', 'Aktina' ); */?></h2>
			                </div>
							<div class="modal-body">
								<form id="forgot_form" name="login_form" method="post" class="forget-password-form" action="<?php /*echo site_url( 'wp-login.php?action=lostpassword', 'login_post' ) */?>">
									<span class="form-section first">
										<label><?php /*_e( 'Your Username or E-mail', 'Aktina' ); */?></label>
										<input type="text" id="forgot-email" name="user_login" class="text-input">
									</span>
									<?php /*do_action( 'lostpassword_form' ); */?>
									<span class="form-section">
										<input type="submit" id="recover" name="submit" class="login-button" value="<?php /*_e( "Send me a password", 'Aktina' );*/?>">
									</span>
								</form>
							</div>
							<div class="modal-footer default">
								<?php /*_e( "Remember password?", 'Aktina' ); */?>
								<a href="#" class="login-modal modal-link" data-toggle="modal" data-target="#myModalLogin"><?php /*_e( "Login!", 'Aktina' ); */?></a>
							</div>
						</div>
					</div>
				</div>-->
			<?php
			}
		}
}

add_action( 'wp_footer', 'hsi_user_modal' );

// =============  Enqueue Scripts For Login/Register Modal

function ajax_hsi_login_reg_script() {
	//echo get_the_id();
	if (!is_user_logged_in() ) {
	  wp_enqueue_script( 'ajax_login', plugins_url() . '/ajax-login-reg/js/ajax_login.js', array('jquery'), '', true );
	  wp_enqueue_script( 'remodal', plugins_url() . '/ajax-login-reg/js/remodal.js', array('jquery'), '', true );
	  wp_enqueue_script( 'g-recapthca', 'https://www.google.com/recaptcha/api.js', array('jquery'), '', true );
	  wp_localize_script( 'ajax_login', 'ajaxloginreg', array(
					'ajaxurl' => admin_url('admin-ajax.php'),
				) );
	  wp_enqueue_style('product_designs_css', plugins_url() . '/ajax-login-reg/css/login-modal.css');
	  wp_enqueue_style('remodal', plugins_url() . '/ajax-login-reg/css/remodal.css');
	  wp_enqueue_style('remodal-def', plugins_url() . '/ajax-login-reg/css/remodal-default-theme.css');
	}
}

add_action( 'wp_enqueue_scripts', 'ajax_hsi_login_reg_script',99 );



/* AJAX add all variations of a product to cart */

add_action( 'wp_ajax_login_register', 'login_register_callback' );

add_action( 'wp_ajax_nopriv_login_register', 'login_register_callback' );



function login_register_callback() {
	$userData = $_POST['userData'];
	$captcha = filter_input(INPUT_POST, 'captchaResponse');	
	if ($userData['action'] == "register") {
		/* Check if captcha is filled */
		if (!$captcha) {
			http_response_code(401); // Return error code if there is no captcha
		}
		$captcha_response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=6LdmOwsTAAAAAMltv_Q0wfHOjFVJo-WkyjUgPb-W&amp;amp;response=" . $captcha);
		if ($captcha_response . success == false) {
			echo 'SPAM';
			http_response_code(401); // It's SPAM! RETURN SOME KIND OF ERROR
		} else {
		   // Everything is ok and you can proceed by executing your login, signup, update etc scripts
		    $user_id = username_exists( $userData['email'] );
			if ( !$user_id and email_exists($userData['email']) == false ) {
				$user_id = wp_create_user( $userData['email'], $userData['pw'], $userData['email'] );
				if (!is_object($user_id)){
					$user_names = wp_update_user( array( 'ID' => $user_id, 'first_name' => $userData['fname'], 'last_name' => $userData['lname'], 'user_email' => $userData['email'] ) );
				}
				wp_mail($userData['email'], 'Your New Account On HighSchoolImressions.com', 'Welcome to highschoolimpressions.com! Your Username/Email is "' .  $userData['email'] . '" and your password is "' . $userData['pw'] . '". If you ever forget this info, its no biggie! Just go to www.highschoolimpressions.com/login/ and use the forgot password link.');
				$creds = array(
					'user_login'    => $userData['email'],
					'user_password' => $userData['pw']
				);
    			$user = wp_signon( $creds, true );	
				$response['data'] = 'uc';
			} else {
				$result = __('User already exists.  Password inherited.');
				$response['data'] = 'ue';
			}
		}
	}
	if ($userData['action'] == "login") {
		$creds = array(
			'user_login'    => $userData['email'],
			'user_password' => $userData['pw'],
			'rememember'    => $userData['rememberpw']
    	);
		
    	$user = wp_signon( $creds, true );	
		if ( is_wp_error($user) ) {
			wp_mail('web@midwestimpressions.com', 'Test Email', $user->get_error_message());
			echo json_encode(array('loggedin'=>false, 'message'=>__('Wrong username or password.')));
		}
		$response['data'] = 'li';
	}
	$response['status'] = 'success';
	
	$response['loginResult'] = $user;
	$response['createUserResult'] = $user_id;
	$response['message'] = "You Got this!";
	header( 'Content: application/json' );
	echo json_encode( $response );
	die;
}

function add_remodal_atts( $atts, $item, $args ) {
	$menu_items = array('login');
	echo 'test';
	print_r($item);
	wp_mail('rob.c.ruiz@gmail.com', 'remodal atts', json_encode($item));
	if (in_array($item->name, $menu_items)) {
		$atts['data-remodal-target'] = 'login-reg-modal';
	}

	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'add_remodal_atts', 10, 3 );
	
?>