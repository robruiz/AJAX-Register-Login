jQuery(function($){

    if($('[data-remodal-id="login-reg-modal"]').length>0){
        window.loginModal = $('[data-remodal-id="login-reg-modal"]').remodal();

        $('li#menu-item-30').click(function(){
            loginModal.open();
			$('#login-reg-modal.modal').fadeIn();
        });

        $('#back-register, #back-login').click(function(){
            $('section.modal-side').css('width', '49%');
		});
    }

	if ($('button.hsi-login-register').length) {
		//Convert Email Address to lowercase
		$('section.register input#register-email').focusout(function($){
			var email = $(this).val().toLowerCase();
			$(this).val(email);
		});
		//Convert Contact Name, School Name, and Billing Address to Title Case
		$('section.register input#first-name, section.register input#last-name').focusout(function($){
			var str = $(this).val();
			str = str.toLowerCase().replace(/\b[a-z]/g, function(letter) {
				return letter.toUpperCase();
			});
			$(this).val(str);
		});
		//Convert Email Address to lowercase
		$('section.login input#login-email').focusout(function($){
			var email = $(this).val().toLowerCase();
			$(this).val(email);
		});
		$('.hsi-login-modal .modal-side input').change(function(){
			var parSection = $(this).parents('section.modal-side');
			if ($('input', parSection).val().length>0){
                $(this).parents('section.modal-side').css('width', '100%');
				if ($(this).parents('section.modal-side').hasClass('login')){

					$('.hsi-login-modal .modal-side.register').hide();	
					$('#back-register').show();	
				}
				if ($(this).parents('section.modal-side').hasClass('register')){
					$('.hsi-login-modal .modal-side.login').hide();	
					$('#back-login').show();	
					$('.hsi-login-modal section.modal-side.register').css('border-left', 'none');
				}
			} else {
                $(this).parents('section.modal-side').css('width', '49%');
			}
			if ($('input', parSection).val().length == 0) {
				$('.hsi-login-modal .modal-side').css('display', 'inline-block');	
				$('.hsi-login-modal section.modal-side.register').css('border-left', '3px solid #1eaf36');
			}
		});
		$('#back-register button').click(function(){
			$('.hsi-login-modal .modal-side.register').show();	
			$('#back-register').hide();
			$('.hsi-login-modal input').val("");
			$('.hsi-login-modal section.modal-side.register').css('border-left', '3px solid #1eaf36');
		});
		$('#back-login button').click(function(){
			$('.hsi-login-modal .modal-side.login').show();	
			$('#back-login').hide();	
			$('.hsi-login-modal input').val("");
			$('.hsi-login-modal section.modal-side.register').css('border-left', '3px solid #1eaf36');
		});
		$('form#hsi-login-register').submit(function(e) {
			e.preventDefault();
			var userData = {};
			if ($('section.register input#first-name').val().length>0 && $('section.register input#last-name').val().length>0 && $('section.register input#register-email').val().length>0 && $('section.register input#register-password').val().length>0 && $("#g-recaptcha-response").val()){
				
				userData.action = 'register';
				userData.fname = $('section.register input#first-name').val();
				userData.lname = $('section.register input#last-name').val(); 
				userData.email = $('section.register input#register-email').val();
				userData.pw = $('section.register input#register-password').val();
			}
			if ($('section.login input#login-email').val().length>0 && $('section.login input#login-password').val().length>0){
				
				userData.action = 'login';
				userData.email = $('section.login input#login-email').val(); 
				userData.pw = $('section.login input#login-password').val();
				if($('section.login input#remember-password:checked').length>0) {
					userData.rememberpw = true;
				} else { userData.rememberpw = false; }
			}
			if (userData.action == 'login' || userData.action == 'register'){
				var contButton = $('button#hsi-login-modal-continue', '.hsi-login-modal form#hsi-login-register');
				$('button#hsi-login-modal-continue', '.hsi-login-modal form#hsi-login-register').remove();
				$('.hsi-login-modal form#hsi-login-register').append('<div class="loading"><img src="/images/loading.gif" /></div>');
				$.post(
				   ajaxloginreg.ajaxurl,
					  {
						   action:   'login_register',
						   userData:     userData, 
						   captchaResponse: $("#g-recaptcha-response").val()
					   },
					  function( response ) {
						  if( response && response.status == 'success' )
						  {		
							 console.log('success');
						  } else {
							  console.log('EPIC FAIL!');
							  userID = response.createUserResult;
						  }
					  }, 
					  'json'					   
				).done(function(data){
					//console.log(data);
					
					
					if (userData.action == 'login' && data.data == "li") {
						$('.modal-side.login').append('<div class="alert-message alert alert-success rounded"><i class="fa fa-check-circle"></i>Login Successful!</div>');
						if ($('button.prod-designed.enabled').length>0){
							var jobID;
							gaEvent('PD-Logged In', 'UserID='+data.loginResult.ID);
							//console.log(data.loginResult.ID);
							//console.log(jobID);
							saveProdDesign(data.loginResult.ID, jobID);
						} else {
							gaEvent('Site-Logged In', 'UserID='+data.loginResult.ID);
							location.reload(); 
						}
					}
					if (userData.action == 'register' && data.data == "uc") {
						
						$('form', '.hsi-login-modal').remove();
						$('.hsi-login-modal .modal-content').append('<div class="created-user"><h3><p>We Just Created and Account on HighSchoolImpressions.com for you</h3> This is just so we can save your product, design, and order information for you. We also just sent you an email with your login information.</p><p><strong>READ THIS: </strong>Be sure to check your SPAM, Trash, or Clutter folders in your email for your login information email (many times they end up there) if it does not show up in your inbox. Some schools block email at the server level and you may not find an email ANYWHERE! If this is the case, simply use our online chat or send an email to web@midwestimpressions.com to get your login credentials.</p><a class="close-modal" data-dismiss="modal" href="#"><button id="cust-design-go" class="btn pd-btn">OK</button></a></div>');
						if ($('button.prod-designed.enabled').length>0){
							var jobID;
							$('button#cust-design-go').click(function(){
								gaEvent('PD-User Registered', 'UserID='+data.createUserResult.ID);
								saveProdDesign(data.createUserResult.ID, jobID);
							});	
						} else {
							gaEvent('Site-User Registered', 'UserID='+data.createUserResult.ID);
							location.reload(); 	
						}
					}
					if (userData.action == 'register' && data.data == "ue") {
						$('form', '.hsi-login-modal').remove();
						$('.hsi-login-modal .modal-content').append('<div class="created-user"><h3><p>An Account Already Exists with this email address</h3> Try doing a password reset with that email address to reset your password and get logged in.</p><p><strong>READ THIS: </strong>Be sure to check your SPAM, Trash, or Clutter folders in your email for your login information email (many times they end up there) if it does not show up in your inbox. Some schools block email at the server level and you may not find an email ANYWHERE! If this is the case, simply use our online chat or send an email to web@midwestimpressions.com to get your login credentials.</p><a class="close-modal" data-dismiss="modal" href="#"><button id="reset-passord-go" class="btn pd-btn">OK</button></a></div>');
						if ($('button.prod-designed.enabled').length>0){
							$('button#reset-passord-go').click(function(){
								gaEvent('PD-User Register Error', 'Product Designer Register Error');
								window.open("/wp-login.php?action=lostpassword");
							});
						}	else  {
							$('button#reset-passord-go').click(function(){
								gaEvent('User Register Error', 'Site Register Error');
								window.location.href = "/wp-login.php?action=lostpassword";
							});
						}
					
					}
				}).fail(function(jqXHR, textStatus, errorThrown){
					if (userData.action == 'login' && $('.modal-side.login .alert-error').length==0) {
						$('.modal-side.login').append('<div class="alert-message alert alert-error rounded"><i class="fa fa-exclamation-triangle"></i>  Wrong User Name or Password</div>');
						gaEvent('User Login Fail', 'Failed AJAX Login');
						$('.hsi-login-modal form#hsi-login-register .loading').remove();
						$('.hsi-login-modal form#hsi-login-register').append(contButton);
					}
					if (userData.action == 'register' && $('.modal-side.register .alert-error').length==0) {
						$('.modal-side.login').append('<div class="alert-message alert alert-error rounded"><i class="fa fa-exclamation-triangle"></i>  Wrong User Name or Password</div>');
						gaEvent('User Login Fail', 'Failed AJAX Login');
						$('.hsi-login-modal form#hsi-login-register .loading').remove();
						$('.hsi-login-modal form#hsi-login-register').append(contButton);
					}
				});
				
			}
		});
	}
	
	function gaEvent(action, label){
		ga('send', {
		  hitType: 'event',
		  eventCategory: 'Product Designer',
		  eventAction: action,
		  eventLabel: label
		});	
	} 

});